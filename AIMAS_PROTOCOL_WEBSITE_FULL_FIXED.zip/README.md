# AIMAS Protocol Website

Landing page proves by experience.
Dashboard executes (XUI).

## Run
```bash
pnpm install
pnpm dev
```

## Env
Create `.env.local`:
```bash
NEXT_PUBLIC_AIMAS_API_URL=https://aimas-api-xxxxxx.us-central1.run.app
```
