---
title: "API Examples"
subtitle: "curl + Node."
---


```bash
curl -X POST "$AIMAS_API/v1/intent" -H "content-type: application/json" -d '{"intent":"..."}'
```

