---
title: "Cloud Run Deploy"
subtitle: "Source deploy + env."
---


```bash
gcloud run deploy aimas-api --source . --region us-central1 --allow-unauthenticated
```

