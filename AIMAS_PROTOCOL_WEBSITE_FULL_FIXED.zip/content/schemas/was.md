---
title: "Was Feedback"
subtitle: "Private calibration."
---

Reflex signals; never public reviews.
