---
title: "Intent Capsule"
subtitle: "Derived input object."
---

Stored representation of intent after normalization. No raw L0.
