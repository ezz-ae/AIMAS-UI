---
title: "NYK"
subtitle: "Versioned identity anchor."
---

Mutations create a new version (re-effective).
