---
title: "Force Notes"
subtitle: "Append-only ledger."
---

Immutable events; supersede via re-effective.
