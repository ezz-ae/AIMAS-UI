---
title: "Fit Matrix"
subtitle: "Output object."
---

ETA · probability · confidence · sensitivity · paths (free + paid).
