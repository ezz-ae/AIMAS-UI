---
title: "Test Vectors"
subtitle: "Fixtures."
---

Add JSON fixtures to validate outputs and invariants.
