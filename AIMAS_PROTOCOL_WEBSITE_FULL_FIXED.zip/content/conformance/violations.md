---
title: "Violations"
subtitle: "Forbidden patterns."
---

Visibility monetization, ranking-as-truth, raw storage, paywalling baseline.
