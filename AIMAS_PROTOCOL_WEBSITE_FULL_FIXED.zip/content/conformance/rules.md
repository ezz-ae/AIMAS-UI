---
title: "Conformance Rules"
subtitle: "Non-negotiables."
---

1) free baseline path; 2) no raw persistence; 3) append-only; 4) versioned NYK; 5) Fit Matrix output.
