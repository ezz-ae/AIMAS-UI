---
title: "Security"
subtitle: "Integrity first."
---

Signed packets, audit traces, adapters separated.
