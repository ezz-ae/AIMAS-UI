---
title: "Governance Process"
subtitle: "How changes happen."
---

RFC PR → tests → tag release.
