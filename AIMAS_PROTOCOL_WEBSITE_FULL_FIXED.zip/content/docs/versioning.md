---
title: "Versioning"
subtitle: "Protocol changes are proposals, not edits."
---


Anything editable is not foundational.
Anything deployable is not a protocol.

Mathematics never resets.
It is rebuilt.

