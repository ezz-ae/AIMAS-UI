---
title: "Implementations"
subtitle: "Replaceable engines, immutable law."
---


AIMAS publishes:
- API reference
- Node kit
- WordPress kit (UI-only)
- adapters (LLM extraction only)

The protocol is the law. Implementations are replaceable.

