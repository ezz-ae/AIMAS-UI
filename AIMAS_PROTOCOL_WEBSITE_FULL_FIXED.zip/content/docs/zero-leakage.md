---
title: "Zero Leakage"
subtitle: "Prevent contamination by design."
---


- L0 raw never persists.
- Force Notes is append-only.
- NYK is versioned (re-effective) — no overwrites.

