---
title: "Architecture"
subtitle: "Surfaces, organs, and the pipeline."
---


## Organs (minimal)

NYK · Force Notes · Was · Triggers · CFS · Monetization

LLMs are optional adapters. They never decide, score, remember, or monetize.

## Pipeline

L0 raw input is ephemeral.

Persist only derived features as the Intent Capsule.

